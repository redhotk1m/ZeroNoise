# FinalProject
Logo Design
Colors
Website programming
website content
Report about website and references
Submit URL


Header - Umair
Color utseende general - Kim
Download knapp + tooltip + redirect - Even
Generell info om produktet + reklame + alt som FAKTISK skal sees på nettsiden home - Henrik
